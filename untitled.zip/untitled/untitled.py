from flask import Flask, send_from_directory, render_template, request, g
from flask_mail import Mail, Message
from flask_wtf import Form
from form_wtf import CommentForm
import os
import sqlite3

app = Flask(__name__)
app.config['secret_key'] = 'development key'
app.config['WTF_CSRF_ENABLED']=False
app.config.update(dict(
    DATABASE=os.path.join(app.root_path, 'jae.db'),
    SECRET_KEY='development key'
))


def connect_py():
    return sqlite3.connect("C:\\Users\\user\\PycharmProject\\untitled.py")

@app.route('/')
def send_index():
    return render_template('myWebsite.html')

@app.route('/About')
def About_index():
    return render_template('myWebsiteAbout.html')


@app.route('/Contact', methods=['GET', 'POST'])
def view_form():
    form = CommentForm()
    if form.validate_on_submit():
        name = form.name.data
        comments = form.comments.data
        with sqlite3.connect(app.config['DATABASE']) as con:
            cur = con.cursor()
            cur.execute("INSERT INTO jaeTable (name, comments) VALUES (?,?)",(name, comments))
            con.commit()
            print('it works')


        return render_template('myWebsiteContact.html', form=form, name=name, comments=comments)
    return render_template('myWebsiteContact.html', form=form)

@app.route('/Gallery')
def Gallery_index():
    return render_template('myWebsiteGallery.html')

@app.route('/<path:path>')
def static_contents(path):
    return send_from_directory('static', path)

if __name__ == '__main__':
    app.debug = True
    port = int(os.getenv('PORT', 8080))
    host = os.getenv('IP', '0.0.0.0')
    app.run()



