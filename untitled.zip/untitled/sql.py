# import sqlite3
#
# with sqlite3.connect("jae.db") as connection:
#
#     cur = connection.cursor()
#     cur.execute("CREATE TABLE jaeTable(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, comments TEXT NOT NULL);")
#
# cur = connection